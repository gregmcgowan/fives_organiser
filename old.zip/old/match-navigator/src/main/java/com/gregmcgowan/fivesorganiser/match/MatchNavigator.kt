package com.gregmcgowan.fivesorganiser.match

interface MatchNavigator {

    fun handleEvent(navEvent: MatchNavigationEvent)

}