package com.gregmcgowan.fivesorganiser.core

data class MatchTypesInfo(
        val minTeamSize: Int,
        val maxTeamSize: Int
)