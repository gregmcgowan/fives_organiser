package com.gregmcgowan.fivesorganiser.match

interface MatchFragment {

    fun consumeBackPress() : Boolean

}